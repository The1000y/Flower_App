import 'package:flower_app/config/base/base_responce.dart';
import 'package:flower_app/features/profile/domain/entities/profile_entity.dart';
import 'package:flower_app/features/profile/domain/repo/profile_repo.dart';
import 'package:injectable/injectable.dart';

@injectable
class GetProfileUseCase {
  final ProfileRepo profileRepo;

  GetProfileUseCase(this.profileRepo);

  Future<BaseResponce<ProfileEntity>> call() {
    return profileRepo.getProfile();
  }
}
