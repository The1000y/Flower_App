// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'get_profile_response_dto.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

GetProfileResponseDto _$GetProfileResponseDtoFromJson(
  Map<String, dynamic> json,
) => GetProfileResponseDto(
  fullName: json['fullName'] as String?,
  email: json['email'] as String?,
  phone: json['phone'] as String?,
  gender: json['gender'] as String?,
  photoUrl: json['photoUrl'] as String?,
);

Map<String, dynamic> _$GetProfileResponseDtoToJson(
  GetProfileResponseDto instance,
) => <String, dynamic>{
  'fullName': instance.fullName,
  'email': instance.email,
  'phone': instance.phone,
  'gender': instance.gender,
  'photoUrl': instance.photoUrl,
};
