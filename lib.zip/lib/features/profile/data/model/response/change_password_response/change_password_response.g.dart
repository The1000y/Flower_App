// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'change_password_response.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

ChangePasswordResponse _$ChangePasswordResponseFromJson(
  Map<String, dynamic> json,
) => ChangePasswordResponse(
  data: json['data'] as bool?,
  isSuccess: json['isSuccess'] as bool?,
  message: json['message'] as String?,
  errorCode: (json['errorCode'] as num?)?.toInt(),
);

Map<String, dynamic> _$ChangePasswordResponseToJson(
  ChangePasswordResponse instance,
) => <String, dynamic>{
  'data': instance.data,
  'isSuccess': instance.isSuccess,
  'message': instance.message,
  'errorCode': instance.errorCode,
};
