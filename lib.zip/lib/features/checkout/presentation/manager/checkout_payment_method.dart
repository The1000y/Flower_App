enum CheckoutPaymentMethod { COD, Card }
