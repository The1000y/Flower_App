import 'package:dio/dio.dart';
import 'package:flower_app/core/constants/api_strings/api_strings.dart';
import 'package:flower_app/core/constants/app_strings/app_strings.dart';
import 'package:flower_app/features/checkout/data/model/responce/checkout_responce.dart';
import 'package:flower_app/features/checkout/data/model/responce/estimation_time_response.dart';

import 'package:injectable/injectable.dart';
import 'package:retrofit/retrofit.dart';

part 'checkout_api_client.g.dart';

@singleton
@RestApi()
abstract class CheckoutApiClient {
  @factoryMethod
  factory CheckoutApiClient(Dio dio) = _CheckoutApiClient;

  @GET(ApiStrings.checkoutDetails)
  Future<CheckoutResponce> getCheckoutDetails();
  @GET(ApiStrings.estimationTime)
  Future<EstimationTimeResponse> getEstimationTime(
    @Query(AppStrings.addressId) String addressId,
  );
}
