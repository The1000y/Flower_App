// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'checkout_error.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

CheckoutError _$CheckoutErrorFromJson(Map<String, dynamic> json) =>
    CheckoutError(
      code: json['code'] as String?,
      field: json['field'] as String?,
    );

Map<String, dynamic> _$CheckoutErrorToJson(CheckoutError instance) =>
    <String, dynamic>{'code': instance.code, 'field': instance.field};
