// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'payment_methods_dto.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

PaymentMethodsDto _$PaymentMethodsDtoFromJson(Map<String, dynamic> json) =>
    PaymentMethodsDto(
      method: json['method'] as String?,
      gateways: (json['gateways'] as List<dynamic>?)
          ?.map((e) => e as String)
          .toList(),
    );

Map<String, dynamic> _$PaymentMethodsDtoToJson(PaymentMethodsDto instance) =>
    <String, dynamic>{'method': instance.method, 'gateways': instance.gateways};
