// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'estimation_time_dto.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

EstimationTimeDto _$EstimationTimeDtoFromJson(Map<String, dynamic> json) =>
    EstimationTimeDto(
      estimatedDeliveryAt: json['estimatedDeliveryAt'] as String?,
    );

Map<String, dynamic> _$EstimationTimeDtoToJson(EstimationTimeDto instance) =>
    <String, dynamic>{'estimatedDeliveryAt': instance.estimatedDeliveryAt};
