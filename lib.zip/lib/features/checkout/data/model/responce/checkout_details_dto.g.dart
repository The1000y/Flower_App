// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'checkout_details_dto.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

CheckoutDetailsDto _$CheckoutDetailsDtoFromJson(Map<String, dynamic> json) =>
    CheckoutDetailsDto(
      subtotal: (json['subtotal'] as num?)?.toInt(),
      deliveryFee: (json['deliveryFee'] as num?)?.toInt(),
      total: (json['total'] as num?)?.toInt(),
      estimatedDeliveryAt: json['estimatedDeliveryAt'] as String?,
      paymentMethods: (json['paymentMethods'] as List<dynamic>?)
          ?.map((e) => PaymentMethodsDto.fromJson(e as Map<String, dynamic>))
          .toList(),
      isGift: json['isGift'] as bool?,
      giftRecipientName: json['giftRecipientName'] as String?,
      giftRecipientPhone: json['giftRecipientPhone'] as String?,
      cartId: json['cartId'] as String?,
      addressId: json['addressId'] as String?,
    );

Map<String, dynamic> _$CheckoutDetailsDtoToJson(CheckoutDetailsDto instance) =>
    <String, dynamic>{
      'subtotal': instance.subtotal,
      'deliveryFee': instance.deliveryFee,
      'total': instance.total,
      'estimatedDeliveryAt': instance.estimatedDeliveryAt,
      'paymentMethods': instance.paymentMethods,
      'isGift': instance.isGift,
      'giftRecipientName': instance.giftRecipientName,
      'giftRecipientPhone': instance.giftRecipientPhone,
      'cartId': instance.cartId,
      'addressId': instance.addressId,
    };
