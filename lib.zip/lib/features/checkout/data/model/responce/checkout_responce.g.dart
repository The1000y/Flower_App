// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'checkout_responce.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

CheckoutResponce _$CheckoutResponceFromJson(Map<String, dynamic> json) =>
    CheckoutResponce(
      success: json['success'] as bool?,
      message: json['message'] as String?,
      data: json['data'] == null
          ? null
          : CheckoutDetailsDto.fromJson(json['data'] as Map<String, dynamic>),
      error: json['error'] == null
          ? null
          : CheckoutError.fromJson(json['error'] as Map<String, dynamic>),
    );

Map<String, dynamic> _$CheckoutResponceToJson(CheckoutResponce instance) =>
    <String, dynamic>{
      'success': instance.success,
      'message': instance.message,
      'data': instance.data,
      'error': instance.error,
    };
