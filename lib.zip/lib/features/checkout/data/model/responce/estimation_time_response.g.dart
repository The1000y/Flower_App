// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'estimation_time_response.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

EstimationTimeResponse _$EstimationTimeResponseFromJson(
  Map<String, dynamic> json,
) => EstimationTimeResponse(
  success: json['success'] as bool?,
  message: json['message'] as String?,
  data: json['data'] == null
      ? null
      : EstimationTimeDto.fromJson(json['data'] as Map<String, dynamic>),
  error: json['error'] == null
      ? null
      : Error.fromJson(json['error'] as Map<String, dynamic>),
);

Map<String, dynamic> _$EstimationTimeResponseToJson(
  EstimationTimeResponse instance,
) => <String, dynamic>{
  'success': instance.success,
  'message': instance.message,
  'data': instance.data,
  'error': instance.error,
};

Error _$ErrorFromJson(Map<String, dynamic> json) =>
    Error(code: json['code'] as String?, field: json['field'] as String?);

Map<String, dynamic> _$ErrorToJson(Error instance) => <String, dynamic>{
  'code': instance.code,
  'field': instance.field,
};
