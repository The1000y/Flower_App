// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'tracking_dto.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

TrackingDto _$TrackingDtoFromJson(Map<String, dynamic> json) => TrackingDto(
  data: json['data'] == null
      ? null
      : TrackingDataDto.fromJson(json['data'] as Map<String, dynamic>),
  isSuccess: json['success'] as bool?,
  message: json['message'] as String?,
  messageLocalized: json['messageLocalized'] as String?,
  statusCode: json['statusCode'] as String?,
);

Map<String, dynamic> _$TrackingDtoToJson(TrackingDto instance) =>
    <String, dynamic>{
      'data': instance.data,
      'success': instance.isSuccess,
      'message': instance.message,
      'messageLocalized': instance.messageLocalized,
      'statusCode': instance.statusCode,
    };

TrackingDataDto _$TrackingDataDtoFromJson(
  Map<String, dynamic> json,
) => TrackingDataDto(
  orderId: json['orderId'] as String?,
  status: json['status'] as String?,
  isLive: json['isLive'] as bool?,
  driver: json['driver'] == null
      ? null
      : DriverDto.fromJson(json['driver'] as Map<String, dynamic>),
  currentLocation: json['currentLocation'] == null
      ? null
      : CurrentLocationDto.fromJson(
          json['currentLocation'] as Map<String, dynamic>,
        ),
  userAddress: json['userAddress'] == null
      ? null
      : UserAddressDto.fromJson(json['userAddress'] as Map<String, dynamic>),
  estimatedDeliveryAt: json['estimatedDeliveryAt'] == null
      ? null
      : DateTime.parse(json['estimatedDeliveryAt'] as String),
  awaitingCustomerConfirmation: json['awaitingCustomerConfirmation'] as bool?,
);

Map<String, dynamic> _$TrackingDataDtoToJson(TrackingDataDto instance) =>
    <String, dynamic>{
      'orderId': instance.orderId,
      'status': instance.status,
      'isLive': instance.isLive,
      'driver': instance.driver,
      'currentLocation': instance.currentLocation,
      'userAddress': instance.userAddress,
      'estimatedDeliveryAt': instance.estimatedDeliveryAt?.toIso8601String(),
      'awaitingCustomerConfirmation': instance.awaitingCustomerConfirmation,
    };

DriverDto _$DriverDtoFromJson(Map<String, dynamic> json) => DriverDto(
  driverId: json['driverId'] as String?,
  name: json['name'] as String?,
  photoUrl: json['photoUrl'] as String?,
  phone: json['phone'] as String?,
);

Map<String, dynamic> _$DriverDtoToJson(DriverDto instance) => <String, dynamic>{
  'driverId': instance.driverId,
  'name': instance.name,
  'photoUrl': instance.photoUrl,
  'phone': instance.phone,
};

CurrentLocationDto _$CurrentLocationDtoFromJson(Map<String, dynamic> json) =>
    CurrentLocationDto(
      lat: (json['lat'] as num?)?.toDouble(),
      lng: (json['lng'] as num?)?.toDouble(),
      recordedAt: json['recordedAt'] == null
          ? null
          : DateTime.parse(json['recordedAt'] as String),
      isStale: json['isStale'] as bool?,
    );

Map<String, dynamic> _$CurrentLocationDtoToJson(CurrentLocationDto instance) =>
    <String, dynamic>{
      'lat': instance.lat,
      'lng': instance.lng,
      'recordedAt': instance.recordedAt?.toIso8601String(),
      'isStale': instance.isStale,
    };

UserAddressDto _$UserAddressDtoFromJson(Map<String, dynamic> json) =>
    UserAddressDto(
      lat: (json['lat'] as num?)?.toDouble(),
      lng: (json['lng'] as num?)?.toDouble(),
      addressLine: json['addressLine'] as String?,
    );

Map<String, dynamic> _$UserAddressDtoToJson(UserAddressDto instance) =>
    <String, dynamic>{
      'lat': instance.lat,
      'lng': instance.lng,
      'addressLine': instance.addressLine,
    };
