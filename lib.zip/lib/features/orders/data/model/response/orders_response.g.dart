// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'orders_response.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

OrdersResponse _$OrdersResponseFromJson(Map<String, dynamic> json) =>
    OrdersResponse(
      message: json['message'] as String,
      data: (json['data'] as List<dynamic>)
          .map((e) => OrderDto.fromJson(e as Map<String, dynamic>))
          .toList(),
    );

Map<String, dynamic> _$OrdersResponseToJson(OrdersResponse instance) =>
    <String, dynamic>{'message': instance.message, 'data': instance.data};

OrderDto _$OrderDtoFromJson(Map<String, dynamic> json) => OrderDto(
  orderId: json['order_id'] as String,
  orderTitle: json['order_title'] as String,
  totalPrice: json['total_price'] as String,
  deliveryDate: json['delivery_date'] as String,
  isActive: json['is_active'] as bool,
  coverImage: json['cover_image'] as String,
);

Map<String, dynamic> _$OrderDtoToJson(OrderDto instance) => <String, dynamic>{
  'order_id': instance.orderId,
  'order_title': instance.orderTitle,
  'total_price': instance.totalPrice,
  'delivery_date': instance.deliveryDate,
  'is_active': instance.isActive,
  'cover_image': instance.coverImage,
};
