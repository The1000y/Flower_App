import 'package:flower_app/features/commerce/domain/entities/cart/cart_item_entity.dart';
import 'package:flower_app/features/commerce/presentation/cart/manager/cubit/cart_cubit.dart';
import 'package:flower_app/features/commerce/presentation/cart/manager/cubit/cart_state.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil_plus/flutter_screenutil_plus.dart';

import '../../../../../../core/constants/app_strings/app_strings.dart';

/// Everything a single cart line needs to render.
typedef _CartItemView = ({CartItemEntity item, int quantity, bool isBusy});

/// A single cart line.
///
/// The widget is presentational: it reads only its own slice of the state with
/// [BlocSelector] (so changing one quantity rebuilds that one line) and emits
/// the requested new quantity through [onQuantityChanged]. Deciding whether that
/// means an update or a removal is the cubit's job.
class CartItem extends StatelessWidget {
  final CartItemEntity item;
  final VoidCallback onDelete;
  final ValueChanged<int> onQuantityChanged;

  const CartItem({
    super.key,
    required this.item,
    required this.onDelete,
    required this.onQuantityChanged,
  });

  @override
  Widget build(BuildContext context) {
    return BlocSelector<CartCubit, CartState, _CartItemView>(
      selector: (state) {
        final currentItem =
            state.data?.items.firstWhere(
              (cartItem) =>
                  cartItem.id == item.id ||
                  cartItem.productId == item.productId,
              orElse: () => item,
            ) ??
            item;

        return (
          item: currentItem,
          quantity: state.displayQuantity(
            currentItem.productId,
            currentItem.quantity,
          ),
          isBusy:
              state.isItemBusy(currentItem.productId) ||
              state.isCartItemRemoving(currentItem.id),
        );
      },
      builder: (context, view) {
        final currentItem = view.item;
        final quantity = view.quantity;
        final lineSubtotal = currentItem.unitPrice * quantity;

        return Padding(
          padding: const EdgeInsets.all(8.0),
          child: Container(
            padding: const EdgeInsets.all(8.0),
            decoration: BoxDecoration(
              border: Border.all(color: Colors.grey.shade300),
              borderRadius: BorderRadius.circular(8.0.r),
            ),
            child: Row(
              children: [
                ClipRRect(
                  borderRadius: BorderRadius.circular(8.r),
                  child: Image.network(
                    currentItem.productImageUrl,
                    width: 80.w,
                    height: 80.h,
                    fit: BoxFit.cover,
                    errorBuilder: (_, _, _) => const Center(
                      child: Icon(Icons.image_not_supported, size: 60),
                    ),
                  ),
                ),

                SizedBox(width: 12.w),

                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  currentItem.productName,
                                  style: TextStyle(
                                    color: Colors.black,
                                    fontSize: 16.sp,
                                    fontWeight: FontWeight.bold,
                                  ),
                                  maxLines: 2,
                                  overflow: TextOverflow.ellipsis,
                                ),

                                Text(
                                  '${AppStrings.currencyEGP}${currentItem.unitPrice.toStringAsFixed(2)}',
                                ),
                              ],
                            ),
                          ),

                          IconButton(
                            onPressed: view.isBusy ? null : onDelete,
                            icon: const Icon(Icons.delete, color: Colors.red),
                          ),
                        ],
                      ),

                      Row(
                        children: [
                          Flexible(
                            child: Text(
                              '${AppStrings.currencyEGP}${lineSubtotal.toStringAsFixed(2)}',
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: TextStyle(
                                color: Colors.black,
                                fontSize: 16.sp,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),

                          const Spacer(),

                          if (view.isBusy)
                            SizedBox(
                              width: 24.w,
                              height: 24.h,
                              child: const CircularProgressIndicator(
                                strokeWidth: 2,
                              ),
                            )
                          else ...[
                            IconButton(
                              onPressed: () => onQuantityChanged(quantity - 1),
                              icon: const Icon(Icons.remove),
                              visualDensity: VisualDensity.compact,
                            ),

                            Text(quantity.toString()),

                            IconButton(
                              onPressed: () => onQuantityChanged(quantity + 1),
                              icon: const Icon(Icons.add),
                              visualDensity: VisualDensity.compact,
                            ),
                          ],
                        ],
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}
