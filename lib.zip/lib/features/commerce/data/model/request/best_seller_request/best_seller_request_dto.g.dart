// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'best_seller_request_dto.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

BestSellerRequestDto _$BestSellerRequestDtoFromJson(
  Map<String, dynamic> json,
) => BestSellerRequestDto(
  page: (json['page'] as num?)?.toInt(),
  pageSize: (json['pageSize'] as num?)?.toInt(),
);

Map<String, dynamic> _$BestSellerRequestDtoToJson(
  BestSellerRequestDto instance,
) => <String, dynamic>{'page': instance.page, 'pageSize': instance.pageSize};
