// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'products_request_dto.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

ProductsRequestDto _$ProductsRequestDtoFromJson(Map<String, dynamic> json) =>
    ProductsRequestDto(
      occasionId: json['occasionId'] as String?,
      categoryId: json['categoryId'] as String?,
      keyword: json['keyword'] as String?,
      sortBy: json['sortBy'] as String?,
      page: (json['page'] as num?)?.toInt(),
      pageSize: (json['pageSize'] as num?)?.toInt(),
    );

Map<String, dynamic> _$ProductsRequestDtoToJson(ProductsRequestDto instance) =>
    <String, dynamic>{
      'occasionId': instance.occasionId,
      'categoryId': instance.categoryId,
      'keyword': instance.keyword,
      'sortBy': instance.sortBy,
      'page': instance.page,
      'pageSize': instance.pageSize,
    };
