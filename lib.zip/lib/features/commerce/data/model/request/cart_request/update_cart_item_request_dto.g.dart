// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'update_cart_item_request_dto.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

UpdateCartItemRequestDto _$UpdateCartItemRequestDtoFromJson(
  Map<String, dynamic> json,
) => UpdateCartItemRequestDto(quantity: (json['quantity'] as num).toInt());

Map<String, dynamic> _$UpdateCartItemRequestDtoToJson(
  UpdateCartItemRequestDto instance,
) => <String, dynamic>{'quantity': instance.quantity};
