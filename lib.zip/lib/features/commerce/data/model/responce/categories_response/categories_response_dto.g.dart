// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'categories_response_dto.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

CategoriesResponseDto _$CategoriesResponseDtoFromJson(
  Map<String, dynamic> json,
) => CategoriesResponseDto(
  data: (json['data'] as List<dynamic>)
      .map((e) => CategoryDto.fromJson(e as Map<String, dynamic>))
      .toList(),
  isSuccess: json['success'] as bool,
  message: json['message'] as String,
  errorCode: json['error'] as String?,
);

Map<String, dynamic> _$CategoriesResponseDtoToJson(
  CategoriesResponseDto instance,
) => <String, dynamic>{
  'data': instance.data,
  'success': instance.isSuccess,
  'message': instance.message,
  'error': instance.errorCode,
};
