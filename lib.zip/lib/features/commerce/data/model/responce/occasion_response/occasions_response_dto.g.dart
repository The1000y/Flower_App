// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'occasions_response_dto.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

OccasionDataDto _$OccasionDataDtoFromJson(Map<String, dynamic> json) =>
    OccasionDataDto(
      items: (json['items'] as List<dynamic>)
          .map((e) => OccasionDto.fromJson(e as Map<String, dynamic>))
          .toList(),
    );

Map<String, dynamic> _$OccasionDataDtoToJson(OccasionDataDto instance) =>
    <String, dynamic>{'items': instance.items};

OccasionsResponseDto _$OccasionsResponseDtoFromJson(
  Map<String, dynamic> json,
) => OccasionsResponseDto(
  data: OccasionDataDto.fromJson(json['data'] as Map<String, dynamic>),
  isSuccess: json['success'] as bool?,
  message: json['message'] as String?,
  errorCode: json['error'] as String?,
);

Map<String, dynamic> _$OccasionsResponseDtoToJson(
  OccasionsResponseDto instance,
) => <String, dynamic>{
  'data': instance.data,
  'success': instance.isSuccess,
  'message': instance.message,
  'error': instance.errorCode,
};
