// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'occasion_dto.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

OccasionDto _$OccasionDtoFromJson(Map<String, dynamic> json) => OccasionDto(
  id: json['id'] as String,
  name: json['name'] as String,
  imageUrl: json['imageUrl'] as String,
);

Map<String, dynamic> _$OccasionDtoToJson(OccasionDto instance) =>
    <String, dynamic>{
      'id': instance.id,
      'name': instance.name,
      'imageUrl': instance.imageUrl,
    };
