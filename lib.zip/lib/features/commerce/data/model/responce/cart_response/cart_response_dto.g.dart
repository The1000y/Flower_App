// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'cart_response_dto.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

CartDataDto _$CartDataDtoFromJson(Map<String, dynamic> json) => CartDataDto(
  items:
      (json['items'] as List<dynamic>?)
          ?.map((e) => CartItemResponseDto.fromJson(e as Map<String, dynamic>))
          .toList() ??
      [],
  subtotal: (json['subtotal'] as num?)?.toDouble() ?? 0.0,
  deliveryFee: (json['deliveryFee'] as num?)?.toDouble(),
  total: (json['total'] as num?)?.toDouble() ?? 0.0,
  hasChanges: json['hasChanges'] as bool? ?? false,
);

Map<String, dynamic> _$CartDataDtoToJson(CartDataDto instance) =>
    <String, dynamic>{
      'items': instance.items,
      'subtotal': instance.subtotal,
      'deliveryFee': instance.deliveryFee,
      'total': instance.total,
      'hasChanges': instance.hasChanges,
    };
