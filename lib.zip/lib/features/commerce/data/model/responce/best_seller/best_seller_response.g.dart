// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'best_seller_response.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

BestSellerResponse _$BestSellerResponseFromJson(Map<String, dynamic> json) =>
    BestSellerResponse(
      data: json['data'] == null
          ? null
          : Data.fromJson(json['data'] as Map<String, dynamic>),
      isSuccess: json['success'] as bool?,
      message: json['message'] as String?,
      errorCode: json['error'] as String?,
    );

Map<String, dynamic> _$BestSellerResponseToJson(BestSellerResponse instance) =>
    <String, dynamic>{
      'data': instance.data,
      'success': instance.isSuccess,
      'message': instance.message,
      'error': instance.errorCode,
    };

Data _$DataFromJson(Map<String, dynamic> json) => Data(
  items: (json['items'] as List<dynamic>?)
      ?.map((e) => ProductDto.fromJson(e as Map<String, dynamic>))
      .toList(),
  pagination: json['pagination'] == null
      ? null
      : Pagination.fromJson(json['pagination'] as Map<String, dynamic>),
);

Map<String, dynamic> _$DataToJson(Data instance) => <String, dynamic>{
  'items': instance.items,
  'pagination': instance.pagination,
};

Pagination _$PaginationFromJson(Map<String, dynamic> json) => Pagination(
  page: (json['page'] as num?)?.toInt(),
  pageSize: (json['pageSize'] as num?)?.toInt(),
  totalCount: (json['totalCount'] as num?)?.toInt(),
  totalPages: (json['totalPages'] as num?)?.toInt(),
  hasNextPage: json['hasNextPage'] as bool?,
  hasPreviousPage: json['hasPreviousPage'] as bool?,
);

Map<String, dynamic> _$PaginationToJson(Pagination instance) =>
    <String, dynamic>{
      'page': instance.page,
      'pageSize': instance.pageSize,
      'totalCount': instance.totalCount,
      'totalPages': instance.totalPages,
      'hasNextPage': instance.hasNextPage,
      'hasPreviousPage': instance.hasPreviousPage,
    };
