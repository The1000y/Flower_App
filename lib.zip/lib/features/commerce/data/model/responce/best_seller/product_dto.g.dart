// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'product_dto.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

ProductDto _$ProductDtoFromJson(Map<String, dynamic> json) => ProductDto(
  id: json['id'] as String?,
  name: json['name'] as String?,
  imageUrl: json['imageUrl'] as String?,
  currency: json['currency'] as String?,
  price: (json['price'] as num?)?.toInt(),
  originalPrice: (json['originalPrice'] as num?)?.toInt(),
  discountPercentage: (json['discountPercentage'] as num?)?.toInt(),
  status: json['status'] as String?,
);

Map<String, dynamic> _$ProductDtoToJson(ProductDto instance) =>
    <String, dynamic>{
      'id': instance.id,
      'name': instance.name,
      'imageUrl': instance.imageUrl,
      'currency': instance.currency,
      'price': instance.price,
      'originalPrice': instance.originalPrice,
      'discountPercentage': instance.discountPercentage,
      'status': instance.status,
    };
