// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'products_response_dto.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

ProductsResponseDto _$ProductsResponseDtoFromJson(Map<String, dynamic> json) =>
    ProductsResponseDto(
      value: json['value'] == null
          ? null
          : ProductListDataDto.fromJson(json['value'] as Map<String, dynamic>),
      data: json['data'] == null
          ? null
          : ProductListDataDto.fromJson(json['data'] as Map<String, dynamic>),
      isSuccess: json['success'] as bool?,
      message: json['message'] as String?,
      errorCode: json['error'] as String?,
    );

Map<String, dynamic> _$ProductsResponseDtoToJson(
  ProductsResponseDto instance,
) => <String, dynamic>{
  'value': instance.value,
  'data': instance.data,
  'success': instance.isSuccess,
  'message': instance.message,
  'error': instance.errorCode,
};

ProductListDataDto _$ProductListDataDtoFromJson(Map<String, dynamic> json) =>
    ProductListDataDto(
      items: (json['items'] as List<dynamic>)
          .map((e) => ProductDto.fromJson(e as Map<String, dynamic>))
          .toList(),
      pagination: json['pagination'] == null
          ? null
          : PaginationDto.fromJson(json['pagination'] as Map<String, dynamic>),
    );

Map<String, dynamic> _$ProductListDataDtoToJson(ProductListDataDto instance) =>
    <String, dynamic>{
      'items': instance.items,
      'pagination': instance.pagination,
    };
