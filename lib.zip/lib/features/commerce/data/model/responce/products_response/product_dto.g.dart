// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'product_dto.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

ProductDto _$ProductDtoFromJson(Map<String, dynamic> json) => ProductDto(
  id: json['id'] as String,
  name: json['name'] as String,
  imageUrl: json['imageUrl'] as String,
  currency: json['currency'] as String?,
  price: (json['price'] as num).toDouble(),
  discountedPrice: (json['discountedPrice'] as num?)?.toDouble(),
  discountPercent: (json['discountPercent'] as num?)?.toDouble(),
  inStock: json['inStock'] as bool?,
);

Map<String, dynamic> _$ProductDtoToJson(ProductDto instance) =>
    <String, dynamic>{
      'id': instance.id,
      'name': instance.name,
      'imageUrl': instance.imageUrl,
      'currency': instance.currency,
      'price': instance.price,
      'discountedPrice': instance.discountedPrice,
      'discountPercent': instance.discountPercent,
      'inStock': instance.inStock,
    };
