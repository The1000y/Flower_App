// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'home_sections_response.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

HomeSectionsResponse _$HomeSectionsResponseFromJson(
  Map<String, dynamic> json,
) => HomeSectionsResponse(
  data: (json['data'] as List<dynamic>?)
      ?.map((e) => SectionDto.fromJson(e as Map<String, dynamic>))
      .toList(),
  isSuccess: json['success'] as bool?,
  message: json['message'] as String?,
  errorCode: json['error'] as String?,
);

Map<String, dynamic> _$HomeSectionsResponseToJson(
  HomeSectionsResponse instance,
) => <String, dynamic>{
  'data': instance.data,
  'success': instance.isSuccess,
  'message': instance.message,
  'error': instance.errorCode,
};
