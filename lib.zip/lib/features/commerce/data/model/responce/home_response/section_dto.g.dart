// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'section_dto.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

SectionDto _$SectionDtoFromJson(Map<String, dynamic> json) => SectionDto(
  id: json['id'] as String?,
  type: json['type'] as String?,
  index: (json['index'] as num?)?.toInt(),
  isActive: json['isActive'] as bool?,
  title: json['title'] as String?,
  occasionId: json['occasionId'] as String?,
  categoryId: json['categoryId'] as String?,
);

Map<String, dynamic> _$SectionDtoToJson(SectionDto instance) =>
    <String, dynamic>{
      'id': instance.id,
      'type': instance.type,
      'index': instance.index,
      'isActive': instance.isActive,
      'title': instance.title,
      'occasionId': instance.occasionId,
      'categoryId': instance.categoryId,
    };
