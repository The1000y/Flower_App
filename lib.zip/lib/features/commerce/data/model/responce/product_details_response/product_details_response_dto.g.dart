// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'product_details_response_dto.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

ProductDetailsResponseDto _$ProductDetailsResponseDtoFromJson(
  Map<String, dynamic> json,
) => ProductDetailsResponseDto(
  value: json['value'] == null
      ? null
      : ProductDetailsDto.fromJson(json['value'] as Map<String, dynamic>),
  data: json['data'] == null
      ? null
      : ProductDetailsDto.fromJson(json['data'] as Map<String, dynamic>),
  isSuccess: json['success'] as bool?,
  message: json['message'] as String?,
  errorCode: json['error'] as String?,
);

Map<String, dynamic> _$ProductDetailsResponseDtoToJson(
  ProductDetailsResponseDto instance,
) => <String, dynamic>{
  'value': instance.value,
  'data': instance.data,
  'success': instance.isSuccess,
  'message': instance.message,
  'error': instance.errorCode,
};
