// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'product_details_dto.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

ProductDetailsDto _$ProductDetailsDtoFromJson(
  Map<String, dynamic> json,
) => ProductDetailsDto(
  id: json['id'] as String,
  name: json['name'] as String,
  imageUrl: json['imageUrl'] as String,
  currency: json['currency'] as String?,
  price: (json['price'] as num).toDouble(),
  discountedPrice: (json['discountedPrice'] as num?)?.toDouble(),
  discountPercent: (json['discountPercent'] as num?)?.toDouble(),
  inStock: json['inStock'] as bool?,
  images: (json['images'] as List<dynamic>?)?.map((e) => e as String).toList(),
  description: json['description'] as String?,
  includes: (json['includes'] as List<dynamic>?)
      ?.map((e) => ProductIncludeItemDto.fromJson(e as Map<String, dynamic>))
      .toList(),
  categoryId: json['categoryId'] as String?,
  occasionIds: (json['occasionIds'] as List<dynamic>?)
      ?.map((e) => e as String)
      .toList(),
);

Map<String, dynamic> _$ProductDetailsDtoToJson(ProductDetailsDto instance) =>
    <String, dynamic>{
      'id': instance.id,
      'name': instance.name,
      'imageUrl': instance.imageUrl,
      'currency': instance.currency,
      'price': instance.price,
      'discountedPrice': instance.discountedPrice,
      'discountPercent': instance.discountPercent,
      'inStock': instance.inStock,
      'images': instance.images,
      'description': instance.description,
      'includes': instance.includes,
      'categoryId': instance.categoryId,
      'occasionIds': instance.occasionIds,
    };
