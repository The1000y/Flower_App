// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'product_include_item_dto.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

ProductIncludeItemDto _$ProductIncludeItemDtoFromJson(
  Map<String, dynamic> json,
) => ProductIncludeItemDto(
  name: json['name'] as String,
  quantity: (json['quantity'] as num?)?.toInt(),
);

Map<String, dynamic> _$ProductIncludeItemDtoToJson(
  ProductIncludeItemDto instance,
) => <String, dynamic>{'name': instance.name, 'quantity': instance.quantity};
