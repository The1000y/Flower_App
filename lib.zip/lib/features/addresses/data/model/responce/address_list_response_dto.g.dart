// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'address_list_response_dto.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

AddressListResponseDto _$AddressListResponseDtoFromJson(
  Map<String, dynamic> json,
) => AddressListResponseDto(
  data: (json['data'] as List<dynamic>?)
      ?.map((e) => AddressDto.fromJson(e as Map<String, dynamic>))
      .toList(),
  isSuccess: json['isSuccess'] as bool?,
  message: json['message'] as String?,
  errorCode: json['errorCode'] as String?,
);

Map<String, dynamic> _$AddressListResponseDtoToJson(
  AddressListResponseDto instance,
) => <String, dynamic>{
  'data': instance.data,
  'isSuccess': instance.isSuccess,
  'message': instance.message,
  'errorCode': instance.errorCode,
};
