// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'area_dto.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

AreaDto _$AreaDtoFromJson(Map<String, dynamic> json) => AreaDto(
  id: json['id'] as String?,
  name: json['name'] as String?,
  cities: (json['cities'] as List<dynamic>?)
      ?.map((e) => CityItemDto.fromJson(e as Map<String, dynamic>))
      .toList(),
);

Map<String, dynamic> _$AreaDtoToJson(AreaDto instance) => <String, dynamic>{
  'id': instance.id,
  'name': instance.name,
  'cities': instance.cities,
};

CityItemDto _$CityItemDtoFromJson(Map<String, dynamic> json) =>
    CityItemDto(id: json['id'] as String?, name: json['name'] as String?);

Map<String, dynamic> _$CityItemDtoToJson(CityItemDto instance) =>
    <String, dynamic>{'id': instance.id, 'name': instance.name};
