// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'areas_response_dto.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

AreasResponseDto _$AreasResponseDtoFromJson(Map<String, dynamic> json) =>
    AreasResponseDto(
      data: (json['data'] as List<dynamic>?)
          ?.map((e) => AreaDto.fromJson(e as Map<String, dynamic>))
          .toList(),
      isSuccess: json['success'] as bool?,
      message: json['message'] as String?,
    );

Map<String, dynamic> _$AreasResponseDtoToJson(AreasResponseDto instance) =>
    <String, dynamic>{
      'data': instance.data,
      'success': instance.isSuccess,
      'message': instance.message,
    };
