// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'address_dto.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

AddressDto _$AddressDtoFromJson(Map<String, dynamic> json) => AddressDto(
  id: json['id'] as String?,
  recipientName: json['recipientName'] as String?,
  recipientPhone: json['recipientPhone'] as String?,
  phone: json['phone'] as String?,
  addressLine: json['addressLine'] as String?,
  city: json['city'] as String?,
  area: json['area'] as String?,
  cityId: json['cityId'] as String?,
  areaId: json['areaId'] as String?,
  lat: (json['lat'] as num?)?.toDouble(),
  lng: (json['lng'] as num?)?.toDouble(),
  latitude: (json['latitude'] as num?)?.toDouble(),
  longitude: (json['longitude'] as num?)?.toDouble(),
  label: json['label'] as String?,
  isDefault: json['isDefault'] as bool?,
  storeId: json['storeId'] as String?,
  isServiceable: json['isServiceable'] as bool?,
  createdAt: json['createdAt'] == null
      ? null
      : DateTime.parse(json['createdAt'] as String),
);

Map<String, dynamic> _$AddressDtoToJson(AddressDto instance) =>
    <String, dynamic>{
      'id': instance.id,
      'recipientName': instance.recipientName,
      'recipientPhone': instance.recipientPhone,
      'phone': instance.phone,
      'addressLine': instance.addressLine,
      'city': instance.city,
      'area': instance.area,
      'cityId': instance.cityId,
      'areaId': instance.areaId,
      'lat': instance.lat,
      'lng': instance.lng,
      'latitude': instance.latitude,
      'longitude': instance.longitude,
      'label': instance.label,
      'isDefault': instance.isDefault,
      'storeId': instance.storeId,
      'isServiceable': instance.isServiceable,
      'createdAt': instance.createdAt?.toIso8601String(),
    };
