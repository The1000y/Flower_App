// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'nearest_store_dto.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

NearestStoreDto _$NearestStoreDtoFromJson(Map<String, dynamic> json) =>
    NearestStoreDto(
      id: json['id'] as String?,
      name: json['name'] as String?,
      address: json['address'] as String?,
      phoneNumber: json['phoneNumber'] as String?,
      latitude: (json['latitude'] as num?)?.toDouble(),
      longitude: (json['longitude'] as num?)?.toDouble(),
      openingTime: json['openingTime'] as String?,
      closingTime: json['closingTime'] as String?,
    );

Map<String, dynamic> _$NearestStoreDtoToJson(NearestStoreDto instance) =>
    <String, dynamic>{
      'id': instance.id,
      'name': instance.name,
      'address': instance.address,
      'phoneNumber': instance.phoneNumber,
      'latitude': instance.latitude,
      'longitude': instance.longitude,
      'openingTime': instance.openingTime,
      'closingTime': instance.closingTime,
    };
