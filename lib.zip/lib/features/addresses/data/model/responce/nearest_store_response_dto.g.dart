// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'nearest_store_response_dto.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

NearestStoreResponseDto _$NearestStoreResponseDtoFromJson(
  Map<String, dynamic> json,
) => NearestStoreResponseDto(
  data: json['data'] == null
      ? null
      : NearestStoreDto.fromJson(json['data'] as Map<String, dynamic>),
  isSuccess: json['isSuccess'] as bool?,
  message: json['message'] as String?,
);

Map<String, dynamic> _$NearestStoreResponseDtoToJson(
  NearestStoreResponseDto instance,
) => <String, dynamic>{
  'data': instance.data,
  'isSuccess': instance.isSuccess,
  'message': instance.message,
};
