// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'address_response.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

AddressResponse _$AddressResponseFromJson(Map<String, dynamic> json) =>
    AddressResponse(
      data: json['data'] == null
          ? null
          : AddressDto.fromJson(json['data'] as Map<String, dynamic>),
      isSuccess: json['isSuccess'] as bool?,
      message: json['message'] as String?,
      messageLocalized: json['messageLocalized'] as String?,
      statusCode: json['statusCode'] as String?,
    );

Map<String, dynamic> _$AddressResponseToJson(AddressResponse instance) =>
    <String, dynamic>{
      'data': instance.data,
      'isSuccess': instance.isSuccess,
      'message': instance.message,
      'messageLocalized': instance.messageLocalized,
      'statusCode': instance.statusCode,
    };
