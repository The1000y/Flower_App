// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'create_address_request_dto.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

CreateAddressRequestDto _$CreateAddressRequestDtoFromJson(
  Map<String, dynamic> json,
) => CreateAddressRequestDto(
  recipientName: json['recipientName'] as String,
  recipientPhone: json['recipientPhone'] as String,
  addressLine: json['addressLine'] as String,
  city: json['city'] as String,
  area: json['area'] as String,
  lat: (json['lat'] as num?)?.toDouble(),
  lng: (json['lng'] as num?)?.toDouble(),
  label: json['label'] as String?,
);

Map<String, dynamic> _$CreateAddressRequestDtoToJson(
  CreateAddressRequestDto instance,
) => <String, dynamic>{
  'recipientName': instance.recipientName,
  'recipientPhone': instance.recipientPhone,
  'addressLine': instance.addressLine,
  'city': instance.city,
  'area': instance.area,
  'lat': instance.lat,
  'lng': instance.lng,
  'label': instance.label,
};
