// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'update_address_request_dto.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

UpdateAddressRequestDto _$UpdateAddressRequestDtoFromJson(
  Map<String, dynamic> json,
) => UpdateAddressRequestDto(
  recipientName: json['recipientName'] as String?,
  phone: json['phone'] as String?,
  addressLine: json['addressLine'] as String?,
  cityId: json['cityId'] as String?,
  areaId: json['areaId'] as String?,
  latitude: (json['latitude'] as num?)?.toDouble(),
  longitude: (json['longitude'] as num?)?.toDouble(),
  label: json['label'] as String?,
);

Map<String, dynamic> _$UpdateAddressRequestDtoToJson(
  UpdateAddressRequestDto instance,
) => <String, dynamic>{
  'recipientName': instance.recipientName,
  'phone': instance.phone,
  'addressLine': instance.addressLine,
  'cityId': instance.cityId,
  'areaId': instance.areaId,
  'latitude': instance.latitude,
  'longitude': instance.longitude,
  'label': instance.label,
};
