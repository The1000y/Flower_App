// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'place_order_request.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

PlaceOrderRequest _$PlaceOrderRequestFromJson(Map<String, dynamic> json) =>
    PlaceOrderRequest(
      addressId: json['addressId'] as String,
      paymentMethod: json['paymentMethod'] as String,
      paymentGateway: json['paymentGateway'] as String,
      isGift: json['isGift'] as bool?,
      giftRecipientName: json['giftRecipientName'] as String?,
      giftRecipientPhone: json['giftRecipientPhone'] as String?,
    );

Map<String, dynamic> _$PlaceOrderRequestToJson(PlaceOrderRequest instance) =>
    <String, dynamic>{
      'addressId': instance.addressId,
      'paymentMethod': instance.paymentMethod,
      'paymentGateway': instance.paymentGateway,
      'isGift': ?instance.isGift,
      'giftRecipientName': ?instance.giftRecipientName,
      'giftRecipientPhone': ?instance.giftRecipientPhone,
    };
