// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'place_order_response.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

PlaceOrderResponse _$PlaceOrderResponseFromJson(Map<String, dynamic> json) =>
    PlaceOrderResponse(
      data: json['data'] == null
          ? null
          : PlaceOrderDto.fromJson(json['data'] as Map<String, dynamic>),
      isSuccess: json['isSuccess'] as bool?,
      message: json['message'] as String?,
      messageLocalized: json['messageLocalized'] as String?,
      statusCode: json['statusCode'] as String?,
    );

Map<String, dynamic> _$PlaceOrderResponseToJson(PlaceOrderResponse instance) =>
    <String, dynamic>{
      'data': instance.data,
      'isSuccess': instance.isSuccess,
      'message': instance.message,
      'messageLocalized': instance.messageLocalized,
      'statusCode': instance.statusCode,
    };
