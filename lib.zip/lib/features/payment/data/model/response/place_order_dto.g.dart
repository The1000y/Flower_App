// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'place_order_dto.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

PlaceOrderDto _$PlaceOrderDtoFromJson(Map<String, dynamic> json) =>
    PlaceOrderDto(
      orderId: json['orderId'] as String?,
      status: json['status'] as String?,
      gateway: json['gateway'] as String?,
      sessionId: json['sessionId'] as String?,
      sessionUrl: json['sessionUrl'] as String?,
      successUrl: json['successUrl'] as String?,
      cancelUrl: json['cancelUrl'] as String?,
      expiresAt: json['expiresAt'] == null
          ? null
          : DateTime.parse(json['expiresAt'] as String),
      amount: (json['amount'] as num?)?.toDouble(),
      currency: json['currency'] as String?,
      estimatedDeliveryAt: json['estimatedDeliveryAt'] == null
          ? null
          : DateTime.parse(json['estimatedDeliveryAt'] as String),
    );

Map<String, dynamic> _$PlaceOrderDtoToJson(PlaceOrderDto instance) =>
    <String, dynamic>{
      'orderId': instance.orderId,
      'status': instance.status,
      'gateway': instance.gateway,
      'sessionId': instance.sessionId,
      'sessionUrl': instance.sessionUrl,
      'successUrl': instance.successUrl,
      'cancelUrl': instance.cancelUrl,
      'expiresAt': instance.expiresAt?.toIso8601String(),
      'amount': instance.amount,
      'currency': instance.currency,
      'estimatedDeliveryAt': instance.estimatedDeliveryAt?.toIso8601String(),
    };
