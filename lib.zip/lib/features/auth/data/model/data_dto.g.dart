// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'data_dto.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

Map<String, dynamic> _$DatadtoToJson(Datadto instance) => <String, dynamic>{
  'resetToken': instance.resetToken,
  'expiresAtUtc': instance.expiresAtUtc?.toIso8601String(),
};

Map<String, dynamic> _$LoginDataDtoToJson(LoginDataDto instance) =>
    <String, dynamic>{
      'accessToken': instance.accessToken,
      'refreshToken': instance.refreshToken,
      'expiresIn': instance.expiresIn,
      'driverStatus': instance.driverStatus,
      'user': instance.user,
    };
