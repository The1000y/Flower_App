import 'package:flower_app/features/auth/domain/entities/forget_entity/forget_password_entity.dart';
import 'package:json_annotation/json_annotation.dart';
part 'forgot_password_response_dto.g.dart';

@JsonSerializable()
class ForgotPasswordResponseDto {
  @JsonKey(name: 'data')
  final String data;
  @JsonKey(name: 'message')
  final String message;
  @JsonKey(name: 'errorCode')
  final String errorCode;
  @JsonKey(name: 'isSuccess')
  final bool isSuccess;

  ForgotPasswordResponseDto({
    required this.data,
    required this.message,
    required this.errorCode,
    required this.isSuccess,
  });

  ForgetPasswordEntity toDomain() {
    return ForgetPasswordEntity(isSuccess: isSuccess, message: message);
  }

  factory ForgotPasswordResponseDto.fromJson(Map<String, dynamic> json) {
    if (json.containsKey('value')) {
      final value = json['value'];
      final message = value is Map
          ? (value['message']?.toString() ?? '')
          : value?.toString() ?? '';
      return ForgotPasswordResponseDto(
        data: message,
        message: message,
        errorCode: json['error']?.toString() ?? '0',
        isSuccess: json['isSuccess'] == true,
      );
    }
    return _$ForgotPasswordResponseDtoFromJson(json);
  }

  Map<String, dynamic> toJson() => _$ForgotPasswordResponseDtoToJson(this);
}
