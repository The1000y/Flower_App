// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'register_response.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

RegisterResponse _$RegisterResponseFromJson(Map<String, dynamic> json) =>
    RegisterResponse(
      isSuccess: json['isSuccess'] as bool?,
      errorCode: (json['errorCode'] as num?)?.toInt(),
      message: json['message'] as String?,
      data: json['data'] as bool?,
    );

Map<String, dynamic> _$RegisterResponseToJson(RegisterResponse instance) =>
    <String, dynamic>{
      'isSuccess': instance.isSuccess,
      'errorCode': instance.errorCode,
      'message': instance.message,
      'data': instance.data,
    };
