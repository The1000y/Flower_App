// GENERATED CODE - DO NOT MODIFY BY HAND
// dart format width=80

// **************************************************************************
// InjectableConfigGenerator
// **************************************************************************

// ignore_for_file: type=lint
// coverage:ignore-file

// ignore_for_file: no_leading_underscores_for_library_prefixes

import 'package:dio/dio.dart' as _i361;
import 'package:firebase_messaging/firebase_messaging.dart' as _i892;
import 'package:flutter/services.dart' as _i281;
import 'package:flutter_secure_storage/flutter_secure_storage.dart' as _i558;
import 'package:get_it/get_it.dart' as _i174;
import 'package:image_picker/image_picker.dart' as _i183;
import 'package:injectable/injectable.dart' as _i526;
import 'package:shared_preferences/shared_preferences.dart' as _i460;
import 'package:url_launcher_platform_interface/url_launcher_platform_interface.dart'
    as _i252;

import '../../core/locale/locale_cubit.dart' as _i142;
import '../../core/services/firebase_messaging_gateway.dart' as _i992;
import '../../core/services/firebase_messaging_service.dart' as _i1007;
import '../../core/services/firebase_update_messaging_service.dart' as _i781;
import '../../core/services/image_picker_service.dart' as _i428;
import '../../core/services/notification_navigator.dart' as _i938;
import '../../core/services/notification_service.dart' as _i4;
import '../../core/services/order_update_handler.dart' as _i538;
import '../../core/services/url_launcher_service.dart' as _i612;
import '../../features/addresses/api/client/address_api_client.dart' as _i887;
import '../../features/addresses/api/data_source_impl/local/address_local_data_source_impl.dart'
    as _i429;
import '../../features/addresses/api/data_source_impl/local/location_data_source_impl.dart'
    as _i487;
import '../../features/addresses/api/data_source_impl/remote/address_remote_data_source_impl.dart'
    as _i377;
import '../../features/addresses/data/data_source/local_data_source/address_local_data_source.dart'
    as _i61;
import '../../features/addresses/data/data_source/local_data_source/address_local_storage.dart'
    as _i143;
import '../../features/addresses/data/data_source/local_data_source/location_data_source.dart'
    as _i345;
import '../../features/addresses/data/data_source/remote_data_source/address_remote_data_source.dart'
    as _i58;
import '../../features/addresses/data/repo_impl/address_repo_impl.dart'
    as _i781;
import '../../features/addresses/domain/repo/address_repo.dart' as _i824;
import '../../features/addresses/domain/usecases/add_address_use_case.dart'
    as _i974;
import '../../features/addresses/domain/usecases/delete_address_usecase.dart'
    as _i1071;
import '../../features/addresses/domain/usecases/get_addresses_usecase.dart'
    as _i771;
import '../../features/addresses/domain/usecases/get_cities_use_case.dart'
    as _i836;
import '../../features/addresses/domain/usecases/get_current_location_use_case.dart'
    as _i603;
import '../../features/addresses/domain/usecases/get_governomets_use_case.dart'
    as _i733;
import '../../features/addresses/domain/usecases/get_reverse_geocoded_address_use_case.dart'
    as _i394;
import '../../features/addresses/domain/usecases/set_default_address_usecase.dart'
    as _i326;
import '../../features/addresses/domain/usecases/update_address_use_case.dart'
    as _i214;
import '../../features/addresses/presentation/manager/cubit/add_address_cubit.dart'
    as _i958;
import '../../features/auth/api/client/auth_api_client.dart' as _i213;
import '../../features/auth/api/data_source_impl/local/local_data_source_impl.dart'
    as _i906;
import '../../features/auth/api/data_source_impl/remote/remote_data_source_impl.dart'
    as _i713;
import '../../features/auth/api/service/secure_storage.dart' as _i688;
import '../../features/auth/api/service/token_refresh_service.dart' as _i961;
import '../../features/auth/data/data_source/local_data_source/local_data_source.dart'
    as _i843;
import '../../features/auth/data/data_source/remote_data_source/remote_data_source.dart'
    as _i554;
import '../../features/auth/data/repo_impl/auth_repo_impl.dart' as _i279;
import '../../features/auth/domain/repo/auth_repo.dart' as _i170;
import '../../features/auth/domain/use_case/delete_remembered_email_use_case.dart'
    as _i25;
import '../../features/auth/domain/use_case/forget_password_user_case.dart'
    as _i443;
import '../../features/auth/domain/use_case/load_remembered_email_use_case.dart'
    as _i481;
import '../../features/auth/domain/use_case/login_usecase.dart' as _i611;
import '../../features/auth/domain/use_case/register_auth_use_case.dart'
    as _i591;
import '../../features/auth/domain/use_case/reset_password_user_case.dart'
    as _i473;
import '../../features/auth/domain/use_case/save_remembered_email_use_case.dart'
    as _i705;
import '../../features/auth/domain/use_case/verify_otp_user_case.dart' as _i542;
import '../../features/auth/presentation/forget_password/manager/cubit/forget_password_cubit.dart'
    as _i667;
import '../../features/auth/presentation/login/manager/login_view_model.dart'
    as _i693;
import '../../features/auth/presentation/register/manager/register_view_model.dart'
    as _i772;
import '../../features/checkout/api/client/checkout_api_client.dart' as _i970;
import '../../features/checkout/api/data_source_impl/remote_data_source_impl.dart'
    as _i598;
import '../../features/checkout/data/data_source/remote_data_source.dart'
    as _i605;
import '../../features/checkout/data/repo_impl/checkout_repo_impl.dart'
    as _i756;
import '../../features/checkout/domain/repo/checkout_repo.dart' as _i858;
import '../../features/checkout/domain/use_cases/estimation_time_use_case.dart'
    as _i953;
import '../../features/checkout/domain/use_cases/get_checkout_use_case.dart'
    as _i995;
import '../../features/checkout/presentation/manager/cubit/checkout_cubit.dart'
    as _i106;
import '../../features/commerce/api/client/commerce_api_client.dart' as _i990;
import '../../features/commerce/api/data_source_impl/local/best_seller_local_data_source_impl.dart'
    as _i599;
import '../../features/commerce/api/data_source_impl/local/local_data_source_impl.dart'
    as _i425;
import '../../features/commerce/api/data_source_impl/local/product_details_local_data_source_impl.dart'
    as _i658;
import '../../features/commerce/api/data_source_impl/remote/remote_data_source_impl.dart'
    as _i715;
import '../../features/commerce/data/data_source/local_data_source/best_seller_local_data_source.dart'
    as _i89;
import '../../features/commerce/data/data_source/local_data_source/commerce_local_data_source.dart'
    as _i413;
import '../../features/commerce/data/data_source/local_data_source/product_details_local_data_source.dart'
    as _i714;
import '../../features/commerce/data/data_source/remote_data_source/commerce_remote_data_source.dart'
    as _i43;
import '../../features/commerce/data/repo_impl/commerce_repo_impl.dart'
    as _i195;
import '../../features/commerce/data/repo_impl/product_details_repo_impl.dart'
    as _i301;
import '../../features/commerce/domain/repo/commerce_repo.dart' as _i772;
import '../../features/commerce/domain/repo/product_details_repo.dart' as _i426;
import '../../features/commerce/domain/use_case/add_cart_item_use_case.dart'
    as _i580;
import '../../features/commerce/domain/use_case/clear_cart_use_case.dart'
    as _i141;
import '../../features/commerce/domain/use_case/get_best_seller_use_case.dart'
    as _i241;
import '../../features/commerce/domain/use_case/get_cart_use_case.dart'
    as _i262;
import '../../features/commerce/domain/use_case/get_categories_use_case.dart'
    as _i879;
import '../../features/commerce/domain/use_case/get_home_sections_use_case.dart'
    as _i951;
import '../../features/commerce/domain/use_case/get_occasions_use_case.dart'
    as _i35;
import '../../features/commerce/domain/use_case/get_product_details_use_case.dart'
    as _i54;
import '../../features/commerce/domain/use_case/get_product_use_case.dart'
    as _i73;
import '../../features/commerce/domain/use_case/get_products_use_case.dart'
    as _i271;
import '../../features/commerce/domain/use_case/remove_cart_item_use_case.dart'
    as _i358;
import '../../features/commerce/domain/use_case/update_cart_item_use_case.dart'
    as _i469;
import '../../features/commerce/presentation/bestseller/manager/cubit/bestseller_cubit.dart'
    as _i909;
import '../../features/commerce/presentation/cart/manager/cubit/cart_cubit.dart'
    as _i1053;
import '../../features/commerce/presentation/categories/manager/cubit/categories_cubit.dart'
    as _i412;
import '../../features/commerce/presentation/home/manager/cubit/home_cubit.dart'
    as _i69;
import '../../features/commerce/presentation/occasion/manager/cubit/occasion_cubit.dart'
    as _i324;
import '../../features/commerce/presentation/product_details/manager/cubit/product_details_cubit.dart'
    as _i932;
import '../../features/order_tracking/api/client/traking_api_client.dart'
    as _i1067;
import '../../features/order_tracking/api/data_source_impl/remote/tracking_remote_data_source_impl.dart'
    as _i427;
import '../../features/order_tracking/data/data_source/remote_data_source/remote_data_source.dart'
    as _i478;
import '../../features/order_tracking/data/repo_impl/tracking_order_update_handler.dart'
    as _i541;
import '../../features/order_tracking/data/repo_impl/tracking_repository_impl.dart'
    as _i508;
import '../../features/order_tracking/domain/repo/tracking_repository.dart'
    as _i951;
import '../../features/order_tracking/domain/use_case/confirm_order_delivery_use_case.dart'
    as _i601;
import '../../features/order_tracking/domain/use_case/get_tracking_use_case.dart'
    as _i834;
import '../../features/order_tracking/domain/use_case/start_tracking_use_case.dart'
    as _i854;
import '../../features/order_tracking/domain/use_case/stop_tracking_use_case.dart'
    as _i420;
import '../../features/order_tracking/presentation/manager/tracking_view_model.dart'
    as _i547;
import '../../features/orders/api/client/orders_api_client.dart' as _i512;
import '../../features/orders/api/data_source_impl/remote/orders_remote_data_source_impl.dart'
    as _i732;
import '../../features/orders/data/data_source/remote_data_source/orders_remote_data_source.dart'
    as _i448;
import '../../features/orders/data/repo_impl/orders_repo_impl.dart' as _i450;
import '../../features/orders/domain/repo/orders_repo.dart' as _i808;
import '../../features/orders/domain/use_case/get_orders_usecase.dart' as _i147;
import '../../features/orders/presentation/manager/cubit/orders_cubit.dart'
    as _i99;
import '../../features/payment/api/client/payment_api_client.dart' as _i487;
import '../../features/payment/api/data_source_impl/place_order_data_source_impl.dart'
    as _i444;
import '../../features/payment/data/data_source/remote_data_source.dart'
    as _i28;
import '../../features/payment/data/repo_impl/place_order_repo_impl.dart'
    as _i991;
import '../../features/payment/domain/repo/place_order_repo.dart' as _i246;
import '../../features/payment/domain/use_case/place_order_use_case.dart'
    as _i462;
import '../../features/payment/presentation/manager/cubit/place_order_cubit.dart'
    as _i443;
import '../../features/profile/api/client/profile_api_client.dart' as _i418;
import '../../features/profile/api/data_source_impl/remote/profile_remote_data_source_impl.dart'
    as _i534;
import '../../features/profile/data/data_source/remote_data_source/profile_remote_data_source.dart'
    as _i725;
import '../../features/profile/data/repo_impl/profile_repo_impl.dart' as _i481;
import '../../features/profile/domain/repo/profile_repo.dart' as _i364;
import '../../features/profile/domain/use_case/change_password_use_case.dart'
    as _i342;
import '../../features/profile/domain/use_case/get_profile_use_case.dart'
    as _i114;
import '../../features/profile/domain/use_case/update_profile_use_case.dart'
    as _i155;
import '../../features/profile/presentation/manager/cubit/change_password_cubit.dart'
    as _i175;
import '../../features/profile/presentation/manager/cubit/profile_view_model.dart'
    as _i1059;
import '../../features/search/data/repo_impl/search_repo_impl.dart' as _i790;
import '../../features/search/domain/repo/search_repo.dart' as _i1033;
import '../../features/search/domain/usecases/search_products_use_case.dart'
    as _i698;
import '../../features/search/presentation/manger/cubit/search_cubit.dart'
    as _i136;
import '../dio/dio_module.dart' as _i977;
import '../dio/locale_interceptor.dart' as _i935;
import '../utils/secure_storage_module.dart' as _i327;
import 'app_module.dart' as _i460;
import 'di_module.dart' as _i211;

extension GetItInjectableX on _i174.GetIt {
  // initializes the registration of main-scope dependencies inside of GetIt
  Future<_i174.GetIt> init({
    String? environment,
    _i526.EnvironmentFilter? environmentFilter,
  }) async {
    final gh = _i526.GetItHelper(this, environment, environmentFilter);
    final registerModule = _$RegisterModule();
    final appModule = _$AppModule();
    final secureStorageModule = _$SecureStorageModule();
    final imagePickerModule = _$ImagePickerModule();
    final urlLauncherModule = _$UrlLauncherModule();
    final dioModule = _$DioModule();
    await gh.factoryAsync<_i460.SharedPreferences>(
      () => registerModule.prefs,
      preResolve: true,
    );
    gh.lazySingleton<_i281.AssetBundle>(() => appModule.assetBundle);
    gh.lazySingleton<_i892.FirebaseMessaging>(
      () => registerModule.firebaseMessaging,
    );
    gh.lazySingleton<_i558.FlutterSecureStorage>(
      () => secureStorageModule.secureStorage,
    );
    gh.lazySingleton<_i183.ImagePicker>(() => imagePickerModule.imagePicker);
    gh.lazySingleton<_i252.UrlLauncherPlatform>(
      () => urlLauncherModule.urlLauncherPlatform,
    );
    gh.lazySingleton<_i143.AddressLocalStorage>(
      () => _i143.AddressLocalStorage(),
    );
    gh.factory<_i345.LocationDataSource>(() => _i487.LocationDataSourceImpl());
    gh.factory<_i843.LocalDataSource>(() => _i906.LocalDataSourceImpl());
    gh.lazySingleton<_i688.SecureStorageService>(
      () => _i688.SecureStorageService(gh<_i558.FlutterSecureStorage>()),
    );
    gh.lazySingleton<_i413.CommerceLocalDataSource>(
      () => _i425.LocalDataSourceImpl(),
    );
    gh.lazySingleton<_i938.NotificationNavigator>(
      () => _i938.NotificationNavigationNotifier(),
    );
    gh.factory<_i89.BestSellerLocalDataSource>(
      () => _i599.BestSellerLocalDataSourceImpl(),
    );
    gh.lazySingleton<_i992.FirebaseMessagingGateway>(
      () => _i992.FirebaseMessagingGatewayImpl(gh<_i892.FirebaseMessaging>()),
    );
    gh.lazySingleton<_i612.UrlLauncherService>(
      () => _i612.UrlLauncherServiceImpl(gh<_i252.UrlLauncherPlatform>()),
    );
    gh.lazySingleton<_i142.LocaleCubit>(
      () => _i142.LocaleCubit(gh<_i460.SharedPreferences>()),
    );
    gh.factory<_i61.AddressLocalDataSource>(
      () => _i429.AddressLocalDataSourceImpl(
        assetBundle: gh<_i281.AssetBundle>(),
      ),
    );
    gh.lazySingleton<_i428.ImagePickerService>(
      () => _i428.ImagePickerServiceImpl(gh<_i183.ImagePicker>()),
    );
    gh.lazySingleton<_i4.NotificationService>(
      () => _i4.AppNotificationService(gh<_i938.NotificationNavigator>()),
    );
    gh.factory<_i935.LocaleInterceptors>(
      () => _i935.LocaleInterceptors(gh<_i142.LocaleCubit>()),
    );
    gh.lazySingleton<_i361.Dio>(
      () => dioModule.dio(gh<_i935.LocaleInterceptors>()),
    );
    gh.singleton<_i1067.TrackingApiClient>(
      () => _i1067.TrackingApiClient.create(gh<_i361.Dio>()),
    );
    gh.singleton<_i887.AddressApiClient>(
      () => _i887.AddressApiClient(gh<_i361.Dio>()),
    );
    gh.singleton<_i213.AuthApiClient>(
      () => _i213.AuthApiClient(gh<_i361.Dio>()),
    );
    gh.singleton<_i970.CheckoutApiClient>(
      () => _i970.CheckoutApiClient(gh<_i361.Dio>()),
    );
    gh.singleton<_i990.CommerceApiClient>(
      () => _i990.CommerceApiClient(gh<_i361.Dio>()),
    );
    gh.singleton<_i512.OrdersApiClient>(
      () => _i512.OrdersApiClient(gh<_i361.Dio>()),
    );
    gh.singleton<_i487.PaymentApiClient>(
      () => _i487.PaymentApiClient(gh<_i361.Dio>()),
    );
    gh.singleton<_i418.ProfileApiClient>(
      () => _i418.ProfileApiClient(gh<_i361.Dio>()),
    );
    gh.factory<_i448.OrdersRemoteDataSource>(
      () => _i732.OrdersRemoteDataSourceImpl(gh<_i512.OrdersApiClient>()),
    );
    gh.lazySingleton<_i961.TokenRefreshService>(
      () => _i961.TokenRefreshService(
        gh<_i213.AuthApiClient>(),
        gh<_i688.SecureStorageService>(),
      ),
    );
    gh.factory<_i43.CommerceRemoteDataSource>(
      () => _i715.RemoteDataSourceImpl(gh<_i990.CommerceApiClient>()),
    );
    gh.factory<_i725.ProfileRemoteDataSource>(
      () => _i534.ProfileRemoteDataSourceImpl(gh<_i418.ProfileApiClient>()),
    );
    gh.factory<_i28.RemoteDataSource>(
      () => _i444.PlaceOrderDataSourceImpl(gh<_i487.PaymentApiClient>()),
    );
    gh.factory<_i714.ProductDetailsLocalDataSource>(
      () => _i658.ProductDetailsLocalDataSourceImpl(
        gh<_i990.CommerceApiClient>(),
      ),
    );
    gh.factory<_i478.TrackingRemoteDataSource>(
      () => _i427.TrackingRemoteDataSourceImpl(gh<_i1067.TrackingApiClient>()),
    );
    gh.factory<_i426.ProductDetailsRepo>(
      () => _i301.ProductDetailsRepoImpl(
        gh<_i714.ProductDetailsLocalDataSource>(),
      ),
    );
    gh.lazySingleton<_i951.TrackingRepository>(
      () => _i508.TrackingRepositoryImpl(gh<_i478.TrackingRemoteDataSource>()),
    );
    gh.factory<_i246.PlaceOrderRepo>(
      () => _i991.PlaceOrderRepoImpl(
        remoteDataSource: gh<_i28.RemoteDataSource>(),
      ),
    );
    gh.factory<_i808.OrdersRepo>(
      () => _i450.OrdersRepoImpl(gh<_i448.OrdersRemoteDataSource>()),
    );
    gh.factory<_i554.RemoteDataSource>(
      () => _i713.RemoteDataSourceImpl(gh<_i213.AuthApiClient>()),
    );
    gh.factory<_i58.AddressRemoteDataSource>(
      () => _i377.AddressRemoteDataSourceImpl(gh<_i887.AddressApiClient>()),
    );
    gh.factory<_i605.RemoteDataSource>(
      () => _i598.RemoteDataSourceImpl(gh<_i970.CheckoutApiClient>()),
    );
    gh.factory<_i147.GetOrdersUseCase>(
      () => _i147.GetOrdersUseCase(gh<_i808.OrdersRepo>()),
    );
    gh.factory<_i462.PlaceOrderUseCase>(
      () => _i462.PlaceOrderUseCase(placeOrderRepo: gh<_i246.PlaceOrderRepo>()),
    );
    gh.factory<_i364.ProfileRepo>(
      () => _i481.ProfileRepoImpl(gh<_i725.ProfileRemoteDataSource>()),
    );
    gh.factory<_i772.CommerceRepo>(
      () => _i195.CommerceRepoImpl(
        gh<_i413.CommerceLocalDataSource>(),
        gh<_i43.CommerceRemoteDataSource>(),
      ),
    );
    gh.factory<_i271.GetProductsUseCase>(
      () => _i271.GetProductsUseCase(gh<_i772.CommerceRepo>()),
    );
    gh.factory<_i858.CheckoutRepo>(
      () => _i756.CheckoutRepoImpl(gh<_i605.RemoteDataSource>()),
    );
    gh.factory<_i170.AuthRepo>(
      () => _i279.AuthRepoImpl(
        gh<_i843.LocalDataSource>(),
        gh<_i554.RemoteDataSource>(),
        gh<_i688.SecureStorageService>(),
      ),
    );
    gh.factory<_i601.ConfirmOrderDeliveryUseCase>(
      () => _i601.ConfirmOrderDeliveryUseCase(gh<_i951.TrackingRepository>()),
    );
    gh.factory<_i834.GetTrackingUseCase>(
      () => _i834.GetTrackingUseCase(gh<_i951.TrackingRepository>()),
    );
    gh.factory<_i854.StartTrackingUseCase>(
      () => _i854.StartTrackingUseCase(gh<_i951.TrackingRepository>()),
    );
    gh.factory<_i420.StopTrackingUseCase>(
      () => _i420.StopTrackingUseCase(gh<_i951.TrackingRepository>()),
    );
    gh.factory<_i443.PlaceOrderCubit>(
      () => _i443.PlaceOrderCubit(gh<_i462.PlaceOrderUseCase>()),
    );
    gh.factory<_i995.GetCheckoutUseCase>(
      () => _i995.GetCheckoutUseCase(checkoutRepo: gh<_i858.CheckoutRepo>()),
    );
    gh.factory<_i473.ResetPasswordUserCase>(
      () => _i473.ResetPasswordUserCase(authRepo: gh<_i170.AuthRepo>()),
    );
    gh.lazySingleton<_i538.OrderUpdateHandler>(
      () => _i541.TrackingOrderUpdateHandler(gh<_i951.TrackingRepository>()),
    );
    gh.factory<_i25.DeleteRememberedEmailUseCase>(
      () => _i25.DeleteRememberedEmailUseCase(gh<_i170.AuthRepo>()),
    );
    gh.factory<_i481.LoadRememberedEmailUseCase>(
      () => _i481.LoadRememberedEmailUseCase(gh<_i170.AuthRepo>()),
    );
    gh.factory<_i611.LoginUseCase>(
      () => _i611.LoginUseCase(gh<_i170.AuthRepo>()),
    );
    gh.factory<_i705.SaveRememberedEmailUseCase>(
      () => _i705.SaveRememberedEmailUseCase(gh<_i170.AuthRepo>()),
    );
    gh.factory<_i953.EstimationTimeUseCase>(
      () => _i953.EstimationTimeUseCase(gh<_i858.CheckoutRepo>()),
    );
    gh.factory<_i54.GetProductDetailsUseCase>(
      () => _i54.GetProductDetailsUseCase(gh<_i426.ProductDetailsRepo>()),
    );
    gh.factory<_i824.AddressRepo>(
      () => _i781.AddressRepoImpl(
        gh<_i58.AddressRemoteDataSource>(),
        gh<_i345.LocationDataSource>(),
      ),
    );
    gh.factory<_i1071.DeleteAddressUseCase>(
      () => _i1071.DeleteAddressUseCase(gh<_i824.AddressRepo>()),
    );
    gh.factory<_i771.GetAddressesUseCase>(
      () => _i771.GetAddressesUseCase(gh<_i824.AddressRepo>()),
    );
    gh.factory<_i326.SetDefaultAddressUseCase>(
      () => _i326.SetDefaultAddressUseCase(gh<_i824.AddressRepo>()),
    );
    gh.factory<_i214.UpdateAddressUseCase>(
      () => _i214.UpdateAddressUseCase(gh<_i824.AddressRepo>()),
    );
    gh.lazySingleton<_i781.FirebaseUpdateMessagingService>(
      () =>
          _i781.FirebaseUpdateMessagingService(gh<_i538.OrderUpdateHandler>()),
    );
    gh.factory<_i99.OrdersCubit>(
      () => _i99.OrdersCubit(gh<_i147.GetOrdersUseCase>()),
    );
    gh.factory<_i1033.SearchRepo>(
      () => _i790.SearchRepoImpl(gh<_i772.CommerceRepo>()),
    );
    gh.factory<_i932.ProductDetailsCubit>(
      () => _i932.ProductDetailsCubit(gh<_i54.GetProductDetailsUseCase>()),
    );
    gh.factory<_i547.TrackingViewModel>(
      () => _i547.TrackingViewModel(
        gh<_i834.GetTrackingUseCase>(),
        gh<_i854.StartTrackingUseCase>(),
        gh<_i420.StopTrackingUseCase>(),
        gh<_i601.ConfirmOrderDeliveryUseCase>(),
      ),
    );
    gh.factory<_i580.AddCartItemUseCase>(
      () => _i580.AddCartItemUseCase(commerceRepo: gh<_i772.CommerceRepo>()),
    );
    gh.factory<_i141.ClearCartUseCase>(
      () => _i141.ClearCartUseCase(commerceRepo: gh<_i772.CommerceRepo>()),
    );
    gh.factory<_i241.GetBestSellerUseCase>(
      () => _i241.GetBestSellerUseCase(commerceRepo: gh<_i772.CommerceRepo>()),
    );
    gh.factory<_i262.GetCartUseCase>(
      () => _i262.GetCartUseCase(commerceRepo: gh<_i772.CommerceRepo>()),
    );
    gh.factory<_i879.GetCategoriesUseCase>(
      () => _i879.GetCategoriesUseCase(commerceRepo: gh<_i772.CommerceRepo>()),
    );
    gh.factory<_i358.RemoveCartItemUseCase>(
      () => _i358.RemoveCartItemUseCase(commerceRepo: gh<_i772.CommerceRepo>()),
    );
    gh.factory<_i469.UpdateCartItemUseCase>(
      () => _i469.UpdateCartItemUseCase(commerceRepo: gh<_i772.CommerceRepo>()),
    );
    gh.factory<_i106.CheckoutCubit>(
      () => _i106.CheckoutCubit(
        gh<_i995.GetCheckoutUseCase>(),
        gh<_i953.EstimationTimeUseCase>(),
      ),
    );
    gh.factory<_i342.ChangePasswordUseCase>(
      () => _i342.ChangePasswordUseCase(gh<_i364.ProfileRepo>()),
    );
    gh.factory<_i114.GetProfileUseCase>(
      () => _i114.GetProfileUseCase(gh<_i364.ProfileRepo>()),
    );
    gh.factory<_i155.UpdateProfileUseCase>(
      () => _i155.UpdateProfileUseCase(gh<_i364.ProfileRepo>()),
    );
    gh.factory<_i951.GetHomeSectionsUseCase>(
      () => _i951.GetHomeSectionsUseCase(gh<_i772.CommerceRepo>()),
    );
    gh.factory<_i35.GetOccasionsUseCase>(
      () => _i35.GetOccasionsUseCase(gh<_i772.CommerceRepo>()),
    );
    gh.factory<_i73.GetProductUseCase>(
      () => _i73.GetProductUseCase(gh<_i772.CommerceRepo>()),
    );
    gh.factory<_i591.RegisterAuthUseCase>(
      () => _i591.RegisterAuthUseCase(gh<_i170.AuthRepo>()),
    );
    gh.factory<_i1059.ProfileViewModel>(
      () => _i1059.ProfileViewModel(
        gh<_i114.GetProfileUseCase>(),
        gh<_i155.UpdateProfileUseCase>(),
        gh<_i428.ImagePickerService>(),
      ),
    );
    gh.factory<_i324.OccasionCubit>(
      () => _i324.OccasionCubit(
        gh<_i35.GetOccasionsUseCase>(),
        gh<_i271.GetProductsUseCase>(),
      ),
    );
    gh.lazySingleton<_i1007.FirebaseMessagingService>(
      () => _i1007.FirebaseMessagingService(
        gh<_i992.FirebaseMessagingGateway>(),
        gh<_i4.NotificationService>(),
        gh<_i781.FirebaseUpdateMessagingService>(),
      ),
    );
    gh.factory<_i412.CategoriesCubit>(
      () => _i412.CategoriesCubit(
        gh<_i879.GetCategoriesUseCase>(),
        gh<_i73.GetProductUseCase>(),
      ),
    );
    gh.factory<_i175.ChangePasswordCubit>(
      () => _i175.ChangePasswordCubit(gh<_i342.ChangePasswordUseCase>()),
    );
    gh.factory<_i443.ForgetPasswordUserCase>(
      () => _i443.ForgetPasswordUserCase(gh<_i170.AuthRepo>()),
    );
    gh.factory<_i542.VerifyOtpUserCase>(
      () => _i542.VerifyOtpUserCase(gh<_i170.AuthRepo>()),
    );
    gh.factory<_i698.SearchProductsUseCase>(
      () => _i698.SearchProductsUseCase(gh<_i1033.SearchRepo>()),
    );
    gh.factory<_i772.RegisterViewModel>(
      () => _i772.RegisterViewModel(gh<_i591.RegisterAuthUseCase>()),
    );
    gh.factory<_i693.LoginViewModel>(
      () => _i693.LoginViewModel(
        gh<_i611.LoginUseCase>(),
        gh<_i481.LoadRememberedEmailUseCase>(),
        gh<_i705.SaveRememberedEmailUseCase>(),
        gh<_i25.DeleteRememberedEmailUseCase>(),
      ),
    );
    gh.factory<_i667.ForgetPasswordCubit>(
      () => _i667.ForgetPasswordCubit(
        gh<_i542.VerifyOtpUserCase>(),
        gh<_i443.ForgetPasswordUserCase>(),
        gh<_i473.ResetPasswordUserCase>(),
      ),
    );
    gh.factory<_i836.GetCitiesUseCase>(
      () => _i836.GetCitiesUseCase(gh<_i824.AddressRepo>()),
    );
    gh.factory<_i733.GetGovernoratesUseCase>(
      () => _i733.GetGovernoratesUseCase(gh<_i824.AddressRepo>()),
    );
    gh.factory<_i974.AddAddressUseCase>(
      () => _i974.AddAddressUseCase(addressRepo: gh<_i824.AddressRepo>()),
    );
    gh.factory<_i603.GetCurrentLocationUseCase>(
      () =>
          _i603.GetCurrentLocationUseCase(addressRepo: gh<_i824.AddressRepo>()),
    );
    gh.factory<_i394.GetReverseGeocodedAddressUseCase>(
      () => _i394.GetReverseGeocodedAddressUseCase(
        addressRepo: gh<_i824.AddressRepo>(),
      ),
    );
    gh.factory<_i909.BestsellerCubit>(
      () => _i909.BestsellerCubit(gh<_i241.GetBestSellerUseCase>()),
    );
    gh.lazySingleton<_i1053.CartCubit>(
      () => _i1053.CartCubit.create(
        updateCartItemUseCase: gh<_i469.UpdateCartItemUseCase>(),
        removeCartItemUseCase: gh<_i358.RemoveCartItemUseCase>(),
        getCartUseCase: gh<_i262.GetCartUseCase>(),
        addCartItemUseCase: gh<_i580.AddCartItemUseCase>(),
        clearCartUseCase: gh<_i141.ClearCartUseCase>(),
      ),
    );
    gh.factory<_i136.SearchCubit>(
      () => _i136.SearchCubit(gh<_i698.SearchProductsUseCase>()),
    );
    gh.factory<_i69.HomeCubit>(
      () => _i69.HomeCubit(
        gh<_i879.GetCategoriesUseCase>(),
        gh<_i241.GetBestSellerUseCase>(),
        gh<_i951.GetHomeSectionsUseCase>(),
        gh<_i35.GetOccasionsUseCase>(),
      ),
    );
    gh.singleton<_i958.AddressCubit>(
      () => _i958.AddressCubit(
        gh<_i974.AddAddressUseCase>(),
        gh<_i836.GetCitiesUseCase>(),
        gh<_i394.GetReverseGeocodedAddressUseCase>(),
        gh<_i603.GetCurrentLocationUseCase>(),
        gh<_i733.GetGovernoratesUseCase>(),
        gh<_i214.UpdateAddressUseCase>(),
        gh<_i771.GetAddressesUseCase>(),
        gh<_i1071.DeleteAddressUseCase>(),
        gh<_i326.SetDefaultAddressUseCase>(),
      ),
    );
    return this;
  }
}

class _$RegisterModule extends _i211.RegisterModule {}

class _$AppModule extends _i460.AppModule {}

class _$SecureStorageModule extends _i327.SecureStorageModule {}

class _$ImagePickerModule extends _i428.ImagePickerModule {}

class _$UrlLauncherModule extends _i612.UrlLauncherModule {}

class _$DioModule extends _i977.DioModule {}
