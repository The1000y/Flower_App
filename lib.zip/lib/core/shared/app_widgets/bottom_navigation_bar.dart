import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:persistent_bottom_nav_bar_v2/persistent_bottom_nav_bar_v2.dart';

import 'package:flower_app/config/di/di.dart';
import 'package:flower_app/core/themes/app_colors/app_color.dart';
import 'package:flower_app/features/addresses/presentation/manager/cubit/add_address_cubit.dart';
import 'package:flower_app/features/commerce/presentation/cart/view/cart.dart';
import 'package:flower_app/features/commerce/presentation/categories/view/categories.dart';
import 'package:flower_app/features/commerce/presentation/home/manager/cubit/home_cubit.dart';
import 'package:flower_app/features/commerce/presentation/home/view/home_view.dart';
import 'package:flower_app/features/profile/presentation/manager/cubit/profile_view_model.dart';
import 'package:flower_app/features/profile/presentation/view/profile_home_view.dart';

import '../../constants/app_strings/app_strings.dart';

class PersistentBottomNavBarDemo extends StatefulWidget {
  const PersistentBottomNavBarDemo({super.key, this.onCartTabSelected});

  final VoidCallback? onCartTabSelected;

  @override
  State<PersistentBottomNavBarDemo> createState() =>
      _PersistentBottomNavBarDemoState();
}

class _PersistentBottomNavBarDemoState
    extends State<PersistentBottomNavBarDemo> {
  late final PersistentTabController _controller = PersistentTabController(
    initialIndex: 0,
  );

  // late final Widget _homeScreen = HomeView(controller: _controller);

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final homeScreen = MultiBlocProvider(
      providers: [
        BlocProvider.value(value: getIt<HomeCubit>()),
        BlocProvider.value(value: getIt<AddressCubit>()),
      ],
      child: HomeView(controller: _controller),
    );

    final categoriesScreen = const CategoriesView();

    final cartScreen = BlocProvider.value(
      value: getIt<AddressCubit>(),
      child: const CartView(),
    );

    final profileScreen = BlocProvider(
      create: (_) => getIt<ProfileViewModel>(),
      child: const ProfileHomeView(),
    );

    return PersistentTabView(
      controller: _controller,
      onTabChanged: (index) {
        if (index == 2) {
          widget.onCartTabSelected?.call();
        }
      },
      tabs: [
        PersistentTabConfig(
          screen: homeScreen,
          item: ItemConfig(
            icon: const Icon(Icons.home),
            title: AppStrings.navHome,
            activeForegroundColor: AppColors.pinkBase,
          ),
        ),
        PersistentTabConfig(
          screen: categoriesScreen,
          item: ItemConfig(
            icon: const Icon(Icons.category),
            title: AppStrings.navcategories,
            activeForegroundColor: AppColors.pinkBase,
          ),
        ),
        PersistentTabConfig(
          screen: cartScreen,
          item: ItemConfig(
            icon: const Icon(Icons.shopping_cart),
            title: AppStrings.navCart,
            activeForegroundColor: AppColors.pinkBase,
          ),
        ),
        PersistentTabConfig(
          screen: profileScreen,
          item: ItemConfig(
            icon: const Icon(Icons.person),
            title: AppStrings.navProfile,
            activeForegroundColor: AppColors.pinkBase,
          ),
        ),
      ],
      navBarBuilder: (navBarConfig) =>
          Style1BottomNavBar(navBarConfig: navBarConfig),
    );
  }
}
