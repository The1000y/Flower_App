import 'package:flower_app/config/base/base_responce.dart';
import 'package:flower_app/features/auth/data/models/requests/forgot_password_request_dto.dart';
import 'package:flower_app/features/auth/data/models/requests/reset_password_request_dto.dart';
import 'package:flower_app/features/auth/data/models/responses/forgot_password_response_dto.dart';
import 'package:flower_app/features/auth/data/models/responses/reset_password_response_dto.dart';
import 'package:flower_app/features/auth/data/data_source/remote_data_source/remote_data_source.dart';
import 'package:injectable/injectable.dart';

@LazySingleton(as: RemoteDataSource)
class DummyDataSource implements RemoteDataSource {
  @override
  Future<BaseResponce<ForgotPasswordResponseDto>> ForgotPassword(
    ForgotPasswordRequestDto request,
  ) async {
    await Future.delayed(const Duration(seconds: 1));

    return SuccessResponce(
      ForgotPasswordResponseDto(
        data: '',
        message: 'Password reset code sent successfully',
        errorCode: '',
        isSuccess: true,
      ),
    );
  }

  @override
  Future<BaseResponce<ResetPasswordResponseDto>> ResetPassword(
    ResetPasswordRequestDto request,
  ) async {
    await Future.delayed(const Duration(seconds: 1));

    return SuccessResponce(
      ResetPasswordResponseDto(
        data: '',
        message: 'Password reset successfully',
        errorCode: '',
        isSuccess: true,
      ),
    );
  }
}